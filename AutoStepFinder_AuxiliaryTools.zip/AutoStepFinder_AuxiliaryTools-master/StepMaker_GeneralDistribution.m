function [data,TypeOfSim,NumberOfSteps]=StepMaker_GeneralDistribution
%JWJK_B:-------------------------------------------------------------------
%Title:Simulate Step Traces
%Summary: %this function  creates a stepped trace with noise. 
%Approach: Steps and dwell times are taken as random samples from a 
%stepsize - and dwell time distribution. Options for the step size 
% distribution ae 'FlatDistrib'; 'DoubleDistrib' 'TripleDistrib'; 
%'StepTrain', 'Gaussian' 

%Input: none
%Output: step trace, trace type numbe rof steps used.

%Jacob Kerssemakers 2016-18
%:JWJK_B-------------------------------------------------------------------         
    writepath=pwd;
    
    TypeOfSim='Gaussian'; 
    SignalNoiseRatio=(2)^-1;
    NumberOfSteps=250;
    MinStepSize=-70;
    MaxStepSize=100;
    updown=1;  %if 0, growth will 
    StepSizes=zeros(NumberOfSteps,1);
    StepDwellTimes=zeros(NumberOfSteps,1);    
    StepBinAxis=linspace(MinStepSize,MaxStepSize,1000);
    
    
    switch TypeOfSim
       case 'FlatDistrib'
            StepSizeCurve=(1+0*(StepBinAxis));   
            %StepDwellCurve=0*StepBinAxis+100;
            StepDwellCurve=0*StepBinAxis+10+100*rand(1,1000);
       case 'DoubleDistrib'
            StepSizeCurve=(0*(StepBinAxis));
            StepSizeCurve(100)=100;
            StepSizeCurve(1000)=10;
            %StepDwellCurve=0*StepBinAxis+100;
            StepDwellCurve=0*StepBinAxis+10+100*rand(1,1000);
       case 'TripleDistrib'
            StepSizeCurve=(0*(StepBinAxis));
            StepSizeCurve(10)=100;
            StepSizeCurve(30)=30;
            StepSizeCurve(100)=30;
            %StepDwellCurve=0*StepBinAxis+100;
            StepDwellCurve=0*StepBinAxis+1+100*rand(1,1000);
       case 'StepTrain'
            StepSizeCurve=(0*(StepBinAxis));
            [~,sel]=min(abs(StepBinAxis-10));
            StepSizeCurve(sel)=10;
            StepDwellCurve=0*StepBinAxis+100;
        case 'Gaussian'
            peakpos=0.5;  %in units of the step axis
            peakwidth=0.5 %same
            Rng=MaxStepSize-MinStepSize;
            StepSizeCurve=exp(-( (StepBinAxis-(peakpos*Rng+MinStepSize))/(peakwidth*Rng)).^2);
            StepDwellCurve=0*StepBinAxis+10+100*rand(1,1000);
       
    end
    StepSizeCurve=StepSizeCurve/sum(StepSizeCurve);  %normalized dstribution
    SumStepSizeCurve=cumsum(StepSizeCurve);
         
    %build step list
    for jj=1:NumberOfSteps
            SumVal=rand(1);  %pick a random step
            sel=find(SumStepSizeCurve>0);
            NonZeroSumStepSizeCurve=SumStepSizeCurve(sel);
            NonZeroStepBinAxis=StepBinAxis(sel);
            NonZeroStepDwellCurve=StepDwellCurve(sel);
            
            [~,idx]=min(abs(NonZeroSumStepSizeCurve-SumVal));
            StepSizes(jj)=NonZeroStepBinAxis(idx);
            StepDwellTimes(jj)=round(NonZeroStepDwellCurve(idx));
    end    
    %build curve
    Curve=[];
    Level=0;
    for jj=1:NumberOfSteps
        Dwell=StepDwellTimes(jj);
        Step=StepSizes(jj);
        NewSection=Level+Step*ones(Dwell,1);  %sign(randn(1,1))*
        Curve=[Curve ; NewSection];
        Level=Curve(end);
    end    
    Ld=length(Curve);
    TimAx=(1:Ld)';
    MeanStep=median(StepSizes);
    Noise=randn(Ld,1)*SignalNoiseRatio*MeanStep;
    data=[TimAx Curve+Noise];
    if nargin<1
        %close all;
        figure(298);
        subplot(2,2,1);
        bar(StepBinAxis,StepSizeCurve);
        title('Step Sizes');
        subplot(2,2,3); 
        bar(StepBinAxis,StepDwellCurve,'r');
        title('Dwell Times');
        subplot(1,2,2);
        plot(data(:,1),data(:,2));
        title('Demo of StepMaker-GeneralDistribution')
        legend(strcat(TypeOfSim, '-Distribution'));
    end
    SaveName=strcat('testdata_simulated',TypeOfSim,num2str(NumberOfSteps),'_steps_from',...
                    num2str(MinStepSize),'to',num2str(MaxStepSize), '.txt');
    dlmwrite(strcat(writepath,'/',SaveName), data);
    
 