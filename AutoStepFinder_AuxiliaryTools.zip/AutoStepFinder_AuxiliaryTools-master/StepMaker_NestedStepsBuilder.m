function xx=StepMaker_NestedStepsBuilder
%JWJK_B:-------------------------------------------------------------------
%Self-scaling step trace
%
%Summary: this function builds self-scaling step curves to illustrate
%properties of 'S-curve' based stepfinding
%
%Approach: A self-scaling step trace is built as follows: We start with two points
%separated by unit step size, i.e. a unit step between two plateasu of just one point. 
%We concatenating this section Np times with copies of itself. 
%This creates a plateau of Np*2 points. Next,this procedure is repeated on the plateau , 
%now with step size two. In total, this concatenation step is repeated Nc times, 
%increasing the step size from 1 to Nc. Finally, this creates a 'fractal' 
%curve of 2*(Np*2)^Nc points, resembling a square wave lines with smaller 
%square waves which in turn are %lined with even smaller square waves, and so on. 
%Such a curve contains steps at Nc-1 length scales, 
%resulting in as any peaks in the S-curve. The relative abundance and size
%of per 'step scale' detrmines which peak will dominate, 
%since a peak height scales linearly with the abundance of steps and quadratically 
%with the size of associated steps. For  example, with a step size increase of 1 
%and a number increase of factor 2*Nc, peaks will roughly be equal. 
%Note that the rising 'noise tail' in the S-curve, as observed for experimental data, 
%here amounts to the final fitting of unit step sizes and can thus be
%interpred as the 'Nc_th S-peak'.
%Input: repeat factors
%Output: trace
%
%References: Jacob Kers 2017
%
%:JWJK_B-------------------------------------------------------------------
    
    
    Nc=4; %Concatenation doubling repeats (amount to number of S_peaks+1);
    Np=5; %plateau repeats (pushes 'noise tail' to higher Nsteps)
    StepN=1; %increase of step size per 
    xx=[-0.5 0.5] ; %the start unit
    for nn=1:Nc
        stepN=StepN*(2^nn); %steps are growing to keep S-function peaks flat
        leftpart=xx-stepN/2;
        rightpart=xx+stepN/2;
        buf=[leftpart rightpart];
        xx=repmat(buf,1,Np);
    end  
    if nargin<1
        %close all;
        figure(355);
        plot(xx);
        title('Demo of StepMaker-NestedStepsBuilder')
    end

    
    