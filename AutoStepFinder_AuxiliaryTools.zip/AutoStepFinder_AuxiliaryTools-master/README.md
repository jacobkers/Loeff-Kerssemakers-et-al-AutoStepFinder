# AutoStepFinder_AuxiliairyTools
Development of handy tools for autostepfinder, to be shared as .zip
