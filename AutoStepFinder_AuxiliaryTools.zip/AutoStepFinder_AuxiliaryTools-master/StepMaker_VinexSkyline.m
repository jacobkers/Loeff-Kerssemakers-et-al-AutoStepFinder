function data=StepMaker_VinexSkyline
%This program makes a really simple trace containing large steps on a base
%line

nw1=1000; %length of one event 
st1=100;   %level of events
reps=10;  %number of events
st2=9;    %level of small steps
ns=1;     %noise level
subreps=10; %number of high sub-levels per event

close all; data=[];
x=linspace(0,2*pi,nw1);
sig=1;
for ii=1:reps
       blockA=0*x;  %baseline
       blockB=st2*round(0.5+0.5*sin(x*subreps))+sig*st1;
       data=[data blockA blockB];
%      sig=-sig;  %for toggling
end

LD=length(data);
noisy=ns*randn(1,LD);
data=data+noisy;
axz=1:LD;
 plot(data);

 outdata=[axz' data']
    
 outname=strcat(pwd,'\','Vinex',num2str(nw1),'.txt');
 dlmwrite(outname,outdata);
