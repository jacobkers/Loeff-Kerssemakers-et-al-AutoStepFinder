function [dataout,stepinfo]=StepInjector(datain,Label)
%JWJK_B:-------------------------------------------------------------------
%Step Injection
%
%Summary: This function adds fake up-and down steps of known size and 
    %location to real data and keeps track of their placement.
    %This way, we can estimate stepdetection limits. 

%Approach: Prior to step analysis,  a 'square wave' with varying amplitude 
%per step is added to the original data trace. The amplitudes per block 
% are chosen at random, in a range in accordance to the steps sizes of interest in the 
%original data. The locations are chosen at fixed intervals for easy retrieval.
%a small info file is saves containing the step information for later use.
%since we use a square wave, the net growth or shrinkage of the original
%signal is preserved.Further, the number of injected steps is kept low
%compared to the typical step number returned on analyzing the original
%data. Thus, injected steps only rarely occur per trace. To build
%statistics, one original trace is combined with many different square
%waves.
%Next, step analysis is done as usual. 
%Afterwards, the injected steps are collected separately if, and only if, 
%the exact locations match those originally placed. 
%
%Input: step traces
%
%Output: step trace with injected steps; info file on injected steps
%
%References: 
%[1]  Real-time detection of condensin-driven DNA compaction reveals a multistep binding mechanism
% Authors, Jorine Mirjam Eeftens, Shveta Bisht, Jacob Kerssemakers, Christian Haering, Cees Dekker
% Publication date 2017/1/1, Journal bioRxiv
% [2] Assembly dynamics of microtubules at molecular resolution.
% Nature. 2006 Aug 10;442(7103):709-12. Epub 2006 Jun 25.
% Kerssemakers JW1, Munteanu EL, Laan L, Noetzel TL, Janson ME, Dogterom M.
% [3] Loeff, Kerssemakers et al 2017
%:JWJK_B-------------------------------------------------------------------
shoit=0;
if nargin<1
    shoit=1;
    [datain,TypeOfSim,NumberOfSteps]=StepMaker_GeneralDistribution;
    datain=datain(:,2);
    Label=strcat(TypeOfSim,num2str(NumberOfSteps, '%3.0f'),'Rep10');
end


maxstepsize=10;
minstepsize=0E-9;
L_total=length(datain);
L_quarterblock=599;
reps=floor(L_total/(4*L_quarterblock));
        amplitudes=minstepsize+rand(1,reps)*(maxstepsize-minstepsize);
        [~,shuffleidx]=sort(rand(1,reps));
        amplitudes=amplitudes(shuffleidx);

        blockstyle='UpDown';
switch blockstyle
    case 'UpDown'          
        blocktemplate=[zeros(1,L_quarterblock) ones(1,2*L_quarterblock)...
                       zeros(1,L_quarterblock)];
        blockcurve=[];
        for ii=1:reps
            block=amplitudes(ii)*blocktemplate;
            blockcurve=[blockcurve block];
        end
    case 'MonotonouslyDown'
        block=zeros(1,4*L_quarterblock);
        blocktemplate=ones(1,4*L_quarterblock);
        blockcurve=[];       
        for ii=1:reps 
            LastLevel=block(end);
            block=LastLevel-amplitudes(ii)*blocktemplate;
            blockcurve=[blockcurve block];
        end
end
LB=length(blockcurve);
if LB<L_total&&LB>0  %padding
    blockcurve=[blockcurve zeros(1,L_total-LB)+blockcurve(end)];
end
if LB>0
    steplocs=diff(blockcurve);
    indexes=(find(steplocs~=0))';
    steps=(steplocs(indexes))';
    dataout=(datain'+blockcurve)';
else
    indexes=NaN;
    steps=NaN;
    blockcurve=0*datain';
    dataout=(datain+blockcurve');
end

if shoit
    plot(datain,'k-'); hold on;
    plot(blockcurve-0.5*maxstepsize,'b-');
    plot(datain+blockcurve'+4*maxstepsize,'r-');  
    legend('original','probing steps','summed' );
    title('spiking of real data with flat-range, equidistant steps');
    xlabel('time, a.u.');
    ylabel('extension, nm');
    pause(0.1);
end
stepinfo=[indexes steps];

dlmwrite(strcat(pwd,'\StepInjectionInfo\',Label,'_stepinfo.txt'),stepinfo);




