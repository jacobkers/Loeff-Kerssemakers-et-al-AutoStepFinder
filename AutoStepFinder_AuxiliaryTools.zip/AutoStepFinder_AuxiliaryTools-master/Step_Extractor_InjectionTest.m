function Step_Extractor_InjectionTest
%JWJK_B:-------------------------------------------------------------------
%Step Extraction
%
%Summary: %This tool processes the results of a 'step injection'run. This is a
%repeated stepfinding run where artificial steps of varying size are injected 
%in the original data at regular distances. The degree to which these steps
%are found back is a measure for the detection limite of the stepfinder,
%specifically for the used dataset. Prior to step analysis,  a 'square wave' with varying amplitude 
%per step was added to the original data trace. The amplitudes per block 
% are chosen at random, in a range in accordance to the steps sizes of interest in the 
%original data. The locations are chosen at fixed intervals for easy retrieval.
%a small info file is saved containing the step information for later use.
%since we use a square wave, the net growth or shrinkage of the original
%signal is preserved.Further, the number of injected steps is kept low
%compared to the typical step number returned on analyzing the original
%data. Thus, injected steps only rarely occur per trace. To build
%statistics, one original trace is combined with many different square
%waves. Next, step analysis is done as usual. 
%Here, the injected steps are collected separately if, and only if, 
%the exact locations match those originally placed. The stepfinder never
%updates step locations during iterations; Further, accidental non-injected 
%steps on these expected locations turn out to be very rare, so post-selection is easy

%Approach:   
    %1) run the stepfinder to get an idea of the step size range of the
    %original data. For demo purposes, run it on 'testdata_simulatedGaussian250_steps_from-70to100'
    %2) go to the section starting at line 116 in the stepfinder code: and set
    %these values:
        %initval.InjectionRepeatMode=100;  
        %(do not forget to set it back to 1 after testing!)
        % injectprops.minstepsize=0;   %adapt to range original steps (demo:0)
        % injectprops.maxstepsize=50;  %adapt to range original steps (demo:50)    
        % injectprops.L_quarterblock=299;  %keep larger than the original
        % dwell times, as not to change the original data too much (demo:299)
    %3 run the stepfinder again on the demo data. It will now repeat 100
    %times a step fit run, now with injected steps included. Results are saved as
    %separate 'repeats'. 
    %properties of these injected steps are saved in a directory
    %'StepInjectionInfo'.
    %4 Run this program: Step_Extractor_InjectionTest (you may check that
    %the paths are set right)

%
%Input: step finder output files rom ''injection run''
%
%Output: histogram summary; excel files (optional)
%
%References: 
%Written by Jacob Kersemakers, 2018
%[1]  Real-time detection of condensin-driven DNA compaction reveals a multistep binding mechanism
% Authors, Jorine Mirjam Eeftens, Shveta Bisht, Jacob Kerssemakers, Christian Haering, Cees Dekker
% Publication date 2017/1/1, Journal bioRxiv
% [2] Assembly dynamics of microtubules at molecular resolution.
% Nature. 2006 Aug 10;442(7103):709-12. Epub 2006 Jun 25.
% Kerssemakers JW1, Munteanu EL, Laan L, Noetzel TL, Janson ME, Dogterom M.
% [3] Loeff, Kerssemakers et al 2017
%:JWJK_B-------------------------------------------------------------------

codepth=pwd;  
mpath=pwd; %you may replace this by another path

infopath=strcat(mpath, '\StepInjectionInfo\'); 
fitpath=strcat(mpath, '\StepFit_Result\'); 

excelsaveit=0;
repetitioncorrection=100;
bins=25;
cd(infopath); FilNames=dir('*_stepinfo.txt'); cd(codepth); croptextno=13;



AllFiles=length(FilNames);
%FilNames(1).name

AllIndex=[];
AllTime=[];
AllLevelBefore=[];
AllLevelAfter=[];
AllLevelMid=[];
AllStepSizes=[];
AllDwellTimeBefore=[];
AllDwellTimeAfter=[];
AllMeasuredError=[];
AllFitRound=[];        
AllSpikedIndices=[];
AllSpikedStepSizes=[];        
AllNoise=zeros(AllFiles,1);
AllS1max=zeros(AllFiles,1);
AllS2max=zeros(AllFiles,1);

close all

for ii=1:AllFiles
AllFiles-ii+1
%read in all the fit information-------------------------------------------
StepFitsName=strcat(FilNames(ii).name(1:end-croptextno),'_fits.txt');
StepFits=double(dlmread(strcat(fitpath,StepFitsName),',',1,0));       
StepPropsName=strcat(FilNames(ii).name(1:end-croptextno),'_properties.txt');
StepFitProps=double(dlmread(strcat(fitpath,StepPropsName),',',1,0));

StepInjectPropsName=strcat(FilNames(ii).name(1:end-croptextno),'_stepinfo.txt');   
StepInjectProps=double(dlmread(strcat(infopath,StepInjectPropsName),',',1,0));
Equidistance=round(median(diff(StepInjectProps(:,1)))/2);



%Traces: Columns Time ,Data, FinalFit
T=StepFits(:,1);    %time axis
X=StepFits(:,2);    %raw data (on which step fit was done)
FitX=StepFits(:,3); %step fit
Residu=X-FitX;
AllNoise(ii)=std(Residu);


%Step Properties: 
%IndexStep,TimeStep,LevelBefore,LevelAfter,StepSize,
%DwellTimeStepBefore,DwellTimeStepAfter,StepError

Index=StepFitProps(:,1);     
Time=StepFitProps(:,2);    
LevelBefore=StepFitProps(:,3);     
LevelAfter=StepFitProps(:,4); 
LevelMid=(LevelBefore+LevelAfter)/2;
StepSizes=StepFitProps(:,5);    
DwellTimeBefore=StepFitProps(:,6);     
DwellTimeAfter=StepFitProps(:,7);
MeasuredError=StepFitProps(:,8);
SpikedIndices=StepInjectProps(:,1);
SpikedStepSizes=StepInjectProps(:,2);

%collect them
AllIndex=[AllIndex; Index];
AllTime=[AllTime; Time];
AllStepSizes=[AllStepSizes; StepSizes];
AllSpikedIndices=[AllSpikedIndices; SpikedIndices];
AllSpikedStepSizes=[AllSpikedStepSizes; SpikedStepSizes]; 
end        

%% histogram all steps--------------------------------------------- 
minstepsize=nanmin(AllStepSizes);
maxstepsize=nanmax(AllStepSizes);
symplotrange=max([abs(minstepsize) abs(maxstepsize)]);
hx=linspace(minstepsize,maxstepsize,bins);
HistX=(hist(AllStepSizes,hx)')/repetitioncorrection; 

sel2=find(mod(AllSpikedIndices,Equidistance)==0);
InjectStepsOriHist=hist(AllSpikedStepSizes(sel2),hx)'/repetitioncorrection;
sel=find(mod(AllIndex,Equidistance)==0);
SpikedSteps=AllStepSizes(sel);
InjectStepsFoundHist=hist(SpikedSteps,hx)'/repetitioncorrection;
RealStepsfoundHist=(HistX-InjectStepsFoundHist);

Injectresult=[hx' ... 
HistX HistX/nansum(HistX)*100 ...
RealStepsfoundHist (RealStepsfoundHist)/nansum(RealStepsfoundHist)*100 ...
InjectStepsOriHist InjectStepsOriHist/nansum(InjectStepsOriHist)*100 ...
InjectStepsFoundHist InjectStepsFoundHist/nansum(InjectStepsFoundHist)*100 ...
100*InjectStepsFoundHist./InjectStepsOriHist];

subplot(3,1,1);
         plot(T,X,...                                                  %Plot Data
        'LineWidth',2,....                                                  %Linewidth
        'Color',[0,0.2,1]);                                                 %Color line RBG
        hold on
        plot(T,FitX,...                                              %Plot Fit
        'LineWidth',1,....                                                  %Linewidth
        'Color',[1,0.7,0]);                                                 %Color line RBG
        title('Last fitted trace');
        MaxX=Time(end);                                             %Determine length X axis
        MaxY=max(X)*1.2;                                         %Determine length Y axis
        MinY=min(X);                                         %Determine length Y axis
        xlim([0 MaxX]);                                             %Set X axis
        ylim([MinY MaxY]);                                  %Set Y axis
        xlabel('Time (s)','FontSize',12);                                   %Label X axis
        ylabel('Position (A.U.)','FontSize',12);                            %Label Y axis



subplot(3,2,3);
plot(hx,HistX,'k-'); hold on;
bar(hx,RealStepsfoundHist,'b');        
title('Step Histogram');
xlabel('Step size, nm'); ylabel('Counts');
legend('all features','minus detected injects');
hold on;
xlim([-symplotrange symplotrange]);      


subplot(3,2,4);
%histogram PLACED 'spiked' steps         
sel3=find(InjectStepsOriHist~=0);
if ~isempty(sel3)
bar(hx(sel3),InjectStepsOriHist(sel3));
title('Injected Steps, original');
xlabel('Step size, nm'); ylabel('Counts');
end
xlim([-symplotrange symplotrange]);

%histogram DETECTED 'spiked' steps
subplot(3,2,5);
plot(hx,InjectStepsOriHist,'b-'); hold on
bar(hx,InjectStepsFoundHist, 'r'); hold on;

title('Injected Steps, detected');
xlabel('Step size, nm'); ylabel('Counts');
hold on;
legend('Injected' ,'Found');

%legend('All detected steps' ,'Detected probing steps');
legend('original','detected');
xlim([-symplotrange symplotrange]);

subplot(3,2,6);
if length(sel3)>1
bar(hx(sel3),100*InjectStepsFoundHist(sel3)./InjectStepsOriHist(sel3), 'k'); hold on;      
title('Detection probability');
xlabel('Step size, nm'); ylabel('percentage');
hold on;
xlim([-symplotrange symplotrange]);
end 

codepth=pwd;        
saveas(gcf,strcat(mpath, '\StepInjectionInfo\','StepInjectionResult','.jpg'),'jpg');
saveas(gcf,strcat(mpath, '\StepInjectionInfo\','StepInjectionResult'));


if excelsaveit
ColNames=[{'binaxis'}, ...
{'all steps'}, {'all steps normalized'}, ...
{'all minus detected injections'}, {'same, normalized'}, ...
{'injected'}, {'injected, normalized'}, ...
{'injected&detected'}, {'injected&detected, normalized'}, ...
{'detection percentage'}];

erasersheet=NaN*zeros(1E3,10);
xlswrite(strcat(codepth,'\InjectionResults\','StepInjectionResult','.xlsx'),ColNames,'Sheet1','A1');
xlswrite(strcat(codepth,'\InjectionResults\','StepInjectionResult','.xlsx'),erasersheet,'Sheet1','A2');
xlswrite(strcat(codepth,'\InjectionResults\','StepInjectionResult','.xlsx'),Injectresult,'Sheet1','A2');
end
dum=1;
